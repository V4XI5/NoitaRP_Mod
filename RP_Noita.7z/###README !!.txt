Install: Place the "Realistic Particles v.1" folder in steamapps/common/Noita/mods folder.
-----------------------------------------------------------------
-----------------------------------------------------------------
V.1 (initial release)
* "loose_ground" rework. (world reacts more from explosions, making loose sand, ground particles fall down easier)
* "base bomb" rework. (Spawns more smoke particles, more sparks during explosions. (does not affect damage)(only visual)
* "tnt" rework. (Spawns more smoke particles, more sparks during explosions. (does not affect damage)(only visual)

V.1.2:
* Added "Magic_Numbers" additions.
* Enemies drops 4% more blood.
* Enemies drops 4% more acid
* Skulls drops 3% more freezing and gunpowders when killed.
* All barrels emits 3% more Oil, Acid etc.
* Laterns emits 3% more Oil.
* Added multiplier for Gore effects.

V.1.3 soon!
-----------------------------------------------------------------
-----------------------------------------------------------------

Feedback: Message me on discord: username V4Xi5 